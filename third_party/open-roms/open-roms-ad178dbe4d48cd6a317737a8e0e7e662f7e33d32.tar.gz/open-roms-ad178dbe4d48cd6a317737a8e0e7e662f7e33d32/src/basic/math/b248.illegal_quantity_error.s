;; #LAYOUT# STD *       #TAKE
;; #LAYOUT# X16 BASIC_0 #TAKE-OFFSET 2000
;; #LAYOUT# *   BASIC_0 #TAKE
;; #LAYOUT# *   *       #IGNORE

; This file is under the MIT license, it contains code released by Microsoft Corporation.
; See LICENSE for more information.

; Math package - overflow error
;
; This is verified to be identical to the original Microsoft implementation where it was named FCERR.
;

illegal_quantity_error:

    ldx #err_illegal_quantity
    jmp error
